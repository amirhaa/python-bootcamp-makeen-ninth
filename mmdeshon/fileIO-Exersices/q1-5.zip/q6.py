with open('q6_file', 'r+') as f6:
    print(f6.read())
