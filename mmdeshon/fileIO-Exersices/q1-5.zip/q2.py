with open('q2_file') as f2:
    print(len(f2.read()))
