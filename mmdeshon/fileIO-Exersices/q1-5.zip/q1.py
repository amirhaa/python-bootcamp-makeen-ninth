with open('q1_file', 'a+') as f1:
    for i in list(range(12)):
        f1.write(f'{str(i)}\n')
